# 2-1-Mux-Verification-using-UVM
this is for example to learn the UVM methodology 
This Project Contains 2:1 MUX-dut,test,seqeunce,driver,monitor, functional coverage.
