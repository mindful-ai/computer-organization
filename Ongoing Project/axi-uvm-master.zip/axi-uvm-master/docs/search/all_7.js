var searchData=
[
  ['has_5fcoverage',['has_coverage',['../classaxi__agent__config.html#aee6068f913d709f0484ca04765c1241d',1,'axi_agent_config']]],
  ['has_5fscoreboard',['has_scoreboard',['../classaxi__agent__config.html#afd207e56d5fb2671bb3d406da692bc8a',1,'axi_agent_config']]]
];
