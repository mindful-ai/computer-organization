var searchData=
[
  ['toggle_5fpattern',['toggle_pattern',['../classaxi__seq__item.html#afced41002a8d7537bdfae6d8be310000',1,'axi_seq_item']]],
  ['transaction_5fid',['transaction_id',['../classaxi__pipelined__reads__seq.html#a5ab66fa2f78ef1e5f6410b1083f5724b',1,'axi_pipelined_reads_seq::transaction_id()'],['../classaxi__pipelined__writes__seq.html#a97848cf276b91e83661084642e681d49',1,'axi_pipelined_writes_seq::transaction_id()']]]
];
