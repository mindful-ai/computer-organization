var searchData=
[
  ['params_5fpkg',['params_pkg',['../namespaceparams__pkg.html',1,'']]]
];
