var searchData=
[
  ['burst_5fsize_5ft',['burst_size_t',['../axi__pkg_8sv.html#a80eb2d0d4b7978e716989546b93fa848',1,'axi_pkg.sv']]],
  ['burst_5ftype_5ft',['burst_type_t',['../axi__pkg_8sv.html#ac948ddb69d517d21ce13ec363f10b95b',1,'axi_pkg.sv']]]
];
