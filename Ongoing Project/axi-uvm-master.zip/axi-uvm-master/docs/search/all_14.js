var searchData=
[
  ['xfers_5fdone',['xfers_done',['../classaxi__seq.html#aedd71f30b38e538b02c93c20bf210e08',1,'axi_seq']]],
  ['xfers_5fto_5fsend',['xfers_to_send',['../classaxi__seq.html#a2e8ea36ae847bab553e4b01c85a18f32',1,'axi_seq']]]
];
