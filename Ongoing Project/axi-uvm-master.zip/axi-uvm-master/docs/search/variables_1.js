var searchData=
[
  ['bid',['bid',['../axi__pkg_8sv.html#a1037aca20e9a00c0867e3d703afbdfbe',1,'axi_seq_item_b_vector_s::bid()'],['../classaxi__seq__item.html#a9decd4c40bb3d260b437c0800cdd815d',1,'axi_seq_item::bid()']]],
  ['bready_5ftoggle_5fpattern',['bready_toggle_pattern',['../classaxi__agent__config.html#aeee4c72140209307cc8be96a98578f79',1,'axi_agent_config']]],
  ['bresp',['bresp',['../axi__pkg_8sv.html#ad9cdaf47fa03c7b15311a5315a615ca0',1,'axi_seq_item_b_vector_s::bresp()'],['../classaxi__seq__item.html#a8adca2cabc55a8614924b9e2dd806a01',1,'axi_seq_item::bresp()']]],
  ['burst_5fsize',['burst_size',['../classaxi__seq__item.html#a52594723d20d3631aaeae6f20dd5de23',1,'axi_seq_item']]],
  ['burst_5ftype',['burst_type',['../classaxi__seq__item.html#aa91c7e80a8fb385bebe88432a7a7669f',1,'axi_seq_item']]]
];
